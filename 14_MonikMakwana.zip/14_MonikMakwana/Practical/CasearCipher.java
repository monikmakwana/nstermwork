import java.util.*; 
class CasearCipher
{
	public static String encryption(String str)
	{
		String enc_text="";
		for(int i=0;i<str.length();i++)
		{
			char ch=str.charAt(i); 
			if(Character.isUpperCase(ch))
			{
			int asc_ch=(((int)ch+3)-65)%26+65; 
			enc_text=enc_text+(char)asc_ch;

			}
			else
			{
			int asc_ch=(((int)ch+3)-97)%26+97; 
			enc_text=enc_text+(char)asc_ch;
			}
		}
		return enc_text;
	}
	 
	public static String decryption(String str)
	{
		String enc_text="";
		for(int i=0;i<str.length();i++)
		{
			char ch=str.charAt(i); 
			if(Character.isUpperCase(ch))
			{
			int asc_ch=(((int)ch-3)-65)%26+65; 
			enc_text=enc_text+(char)asc_ch;
			}
			else
			{
			int asc_ch=(((int)ch-3)-97)%26+97; 
			enc_text=enc_text+(char)asc_ch;
			}
		}
		return enc_text;
	}
	public static void main(String args[])
	{
		Scanner s=new Scanner(System.in); 
		System.out.print("Enter Plain Text : "); 
		String str=s.nextLine();
		String enc_text=encryption(str);
		System.out.println("Encrypted Text : "+enc_text); 
		String dec_text=decryption(enc_text); 
		System.out.println("Decrypted Text : "+dec_text);
	}
}
