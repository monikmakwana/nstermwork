import java.util.Scanner; 
import java.math.*; 
import java.security.*; 
class MD5
{
	static String encryption(String message)throws Exception
	{
		MessageDigest md=MessageDigest.getInstance("MD5"); 
		byte[] msg=md.digest(message.getBytes());
		BigInteger b=new BigInteger(1,msg); 
		String hashval=b.toString(16); 
		while(hashval.length()<32)
		{
			hashval+=0+hashval;
		}
		return hashval;
	}
	public static void main(String args[])throws Exception
	{
		Scanner s=new Scanner(System.in); 
		System.out.print("\nEnter Text : "); 
		String msg=s.nextLine();
		String enc=encryption(msg); 
		System.out.println("Hash Text : "+enc);
	}
}

